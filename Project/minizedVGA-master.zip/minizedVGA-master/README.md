# minizedVGA
Vivado 2018.1 project based on MiniZed (http://zedboard.org/product/minized) and PMOD VGA (https://store.digilentinc.com/pmod-vga-video-graphics-array/) to render AXI Stream to VGA monitor.
