/*
 * Copyright (c) 2009-2012 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

/*
 * MEAS_HTU21D_Main.c: Console Application for Testing the HTU21D
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include <unistd.h>
#include "platform.h"
#include "xparameters.h"
#include "htu21d.h"

void htu21d_main_menu(void);

int main()
{

    char key_input;
    int i;
    htu21d_status stat;
    float temperature;
    float relative_humidity;
    float dew_point;
    htu21d_battery_status	batt_stat;
    htu21d_heater_status	heat_stat;

    //Initialize the UART
    init_platform();

    printf("Hello World\n");

    // Set the AXI address of the IIC core
    htu21d_init(XPAR_AXI_IIC_JC_BASEADDR);

    // Display the main menu
    htu21d_main_menu();

    // Infinite loop
    while(1){

        // Get keyboard input
        read(1, (char*)&key_input, 1);

        if(key_input == '1'){         //If the '1' key is pressed

            // Send the reset command to the HTU21D
            printf("\n");
            printf("Resetting HTU21D...\n");
            stat = htu21d_reset();

            // Display the status returned from the reset operation
            printf("HTU21D Reset Complete with status: ");
            if(stat==htu21d_status_ok)
                printf("Ok.\n");
            if(stat==htu21d_status_i2c_transfer_error)
                printf("Transfer Error.\n");

            // Wait for another key press and then display the main menu again
            printf("\nPress any key to continue...\n");
            read(1, (char*)&key_input, 1);
            htu21d_main_menu();

        }else if(key_input == '2'){         // If the '2' key is pressed

        	// Display resolution selection menu
            printf("\n");
            printf("Select a resolution:\n");
            printf("  (1)   - 14-Bit Temperature and 12-Bit Relative Humidity\n");
            printf("  (2)   - 12-Bit Temperature and  8-Bit Relative Humidity\n");
            printf("  (3)   - 13-Bit Temperature and 10-Bit Relative Humidity\n");
            printf("  (4)   - 11-Bit Temperature and 11-Bit Relative Humidity\n");

            // Get keyboard input ignoring keypresses that are not or '1' or '2' or '3' or '4'
            read(1, (char*)&key_input, 1);
            while(key_input!='1' && key_input!='2' && key_input!='3' && key_input!='4'){
                read(1, (char*)&key_input, 1);
            }

            if(key_input == '1'){           // If the '1' key is pressed
                // Set resolution to 12-bit RH and 14-bit Temp
                stat = htu21d_set_resolution(htu21d_resolution_t_14b_rh_12b);
                printf("\nSetting HTU21D Resolution to 14-bit Temperature and 12-bit Relative Humidity\n");
            }else if(key_input == '2'){     // If the '2' key is pressed
                // Set resolution to  8-bit RH and 12-bit Temp
                stat = htu21d_set_resolution(htu21d_resolution_t_12b_rh_8b);
                printf("\nSetting HTU21D Resolution to 12-bit Temperature and  8-bit Relative Humidity\n");
            }else if(key_input == '3'){     // If the '3' key is pressed
                // Set resolution to 10-bit RH and 13-bit Temp
                stat = htu21d_set_resolution(htu21d_resolution_t_13b_rh_10b);
                printf("\nSetting HTU21D Resolution to 13-bit Temperature and 10-bit Relative Humidity\n");
            }else if(key_input == '4'){     // If the '4' key is pressed
                // Set resolution to 11-bit RH and 11-bit Temp
                stat = htu21d_set_resolution(htu21d_resolution_t_11b_rh_11b);
                printf("\nSetting HTU21D Resolution to 11-bit Temperature and 11-bit Relative Humidity\n");
            }

            // Display the status returned from the set resolution operation
            printf("HTU21D Set Resolution Complete with status: ");
            if(stat==htu21d_status_ok)
                printf("Ok.\n");
            if(stat==htu21d_status_i2c_transfer_error)
                printf("Transfer Error.\n");


            // Wait for another key press and then display the main menu again
            printf("\nPress any key to continue...\n");
            read(1, (char*)&key_input, 1);
            htu21d_main_menu();

        }else if(key_input == '3'){         // If the '3' key is pressed

        	// Read Temperature and Relative Humidity once
            printf("\n");
            printf("Reading Temperature and Relative Humidity...\n");
            stat = htu21d_read_temperature_and_relative_humidity(&temperature, &relative_humidity);

            // Display the status returned from the read_temperature and relative humidity
            // operation and display the temperature and relative humidity if successful
            printf("Temperature and Relative Humidity Read Complete with status: ");
            if(stat==htu21d_status_ok){
                printf("Ok.\n");
                printf("Temperature : %5.2f%cC, \tRelative Humidity : %4.1f%%",temperature,248,relative_humidity);
            }else if(stat==htu21d_status_i2c_transfer_error){
                printf("Transfer Error.");
            }else if(stat==htu21d_status_crc_error){
            	printf("CRC Error.");
            }
            printf("\n");

            // Wait for another key press and then display the main menu again
            printf("\nPress any key to continue...\n");
            read(1, (char*)&key_input, 1);
            htu21d_main_menu();

        }else if(key_input == '4'){         // If the '4' key is pressed

            // Read 20 temperature and relative humidity values at ~2 per second
            printf("\n");
            printf("Reading 20 Temperature and Relative Humidity Values...\n");
            for(i=0;i<20;i++){
                stat = htu21d_read_temperature_and_relative_humidity(&temperature, &relative_humidity);
                printf("%2d: ",i+1);
                if(stat==htu21d_status_ok){
                    printf("%5.2f%cC, \t%4.1f%%",temperature,248,relative_humidity);
                }else if(stat==htu21d_status_i2c_transfer_error){
                    printf("Transfer Error.");
                }else if(stat==htu21d_status_crc_error){
                	printf("CRC Error.");
                }
                printf("\n");
                usleep( (500-HTU21D_14B_CONV_DELAY_MS)*1000 );
            }

            // Wait for another key press and then display the main menu again
            printf("\nPress any key to continue...\n");
            read(1, (char*)&key_input, 1);
            htu21d_main_menu();

        }else if(key_input == '5'){         //If the '5' key is pressed

            // Compute Dew Point from last read Temperature and Relative Humidity values
            printf("\n");
            printf("Computing Dew Point from last read Temperature and Relative Humidity values...\n");
            dew_point = htu21d_compute_dew_point(temperature, relative_humidity);

            printf("Dew Point : %5.2f%cC",dew_point,248);

            // Wait for another key press and then display the main menu again
            printf("\nPress any key to continue...\n");
            read(1, (char*)&key_input, 1);
            htu21d_main_menu();

        }else if(key_input == '6'){         //If the '6' key is pressed

            // Get Battery Status
            printf("\n");
            printf("Getting Battery Status...\n");
            stat = htu21d_get_battery_status(&batt_stat);

            // Display the status returned from the battery status check operation
            printf("Get Battery Status Check Complete with status: ");
            if(stat==htu21d_status_ok)
                printf("Ok.\n");
            	printf("Battery ");
            	if(batt_stat == htu21d_battery_ok){
            		printf("Ok.\n");
            	}else{
            		printf("Low.\n");
            	}
            if(stat==htu21d_status_i2c_transfer_error)
                printf("Transfer Error.\n");

            // Wait for another key press and then display the main menu again
            printf("\nPress any key to continue...\n");
            read(1, (char*)&key_input, 1);
            htu21d_main_menu();

        }else if(key_input == '7'){         //If the '7' key is pressed

            // Get Heater Status
            printf("\n");
            printf("Getting Heater Status...\n");
            stat = htu21d_get_heater_status(&heat_stat);

            // Display the status returned from the heater status check operation
            printf("Get Heater Status Check Complete with status: ");
            if(stat==htu21d_status_ok){
                printf("Ok.\n");
            	printf("Heater ");
            	if(heat_stat == htu21d_heater_on){
            		printf("On.\n");
            	}else{
            		printf("Off.\n");
            	}
            }else if(stat==htu21d_status_i2c_transfer_error)
                printf("Transfer Error.\n");

            // Wait for another key press and then display the main menu again
            printf("\nPress any key to continue...\n");
            read(1, (char*)&key_input, 1);
            htu21d_main_menu();

        }else if(key_input == '8'){         //If the '8' key is pressed

            // Enable heater
            printf("\n");
            printf("Enabling Heater...\n");
            stat = htu21d_enable_heater();

            // Display the status returned from the enable heater operation
            printf("Enable Heater Operation Complete with status: ");
            if(stat==htu21d_status_ok)
                printf("Ok.\n");
            if(stat==htu21d_status_i2c_transfer_error)
                printf("Transfer Error.\n");

            // Wait for another key press and then display the main menu again
            printf("\nPress any key to continue...\n");
            read(1, (char*)&key_input, 1);
            htu21d_main_menu();

        }else if(key_input == '9'){         //If the '9' key is pressed

            // Disable heater
            printf("\n");
            printf("Disabling Heater...\n");
            stat = htu21d_disable_heater();

            // Display the status returned from the disable heater operation
            printf("Disable Heater Operation Complete with status: ");
            if(stat==htu21d_status_ok)
                printf("Ok.\n");
            if(stat==htu21d_status_i2c_transfer_error)
                printf("Transfer Error.\n");

            // Wait for another key press and then display the main menu again
            printf("\nPress any key to continue...\n");
            read(1, (char*)&key_input, 1);
            htu21d_main_menu();

        }else if(key_input == 27){    // If the 'ESC' key is pressed

            // Print done and exit.
            printf("Done.\n");
            break;

        }else{                      // If some other key is pressed

            // Redisplay the main menu
            htu21d_main_menu();

        }
    }

    return 0;

}

void htu21d_main_menu(void){

    //Clear the screen
    printf("\033[2J");

    //Display the main menu
    printf("*******************************************\n");
    printf("****      Measurement Specialties      ****\n");
    printf("*******************************************\n");

    printf("\n");
    printf("   HTU21D - Humidity/Temperature Sensor   \n");
    printf("------------------------------------------\n");

    printf("\n");
    printf("Select a task:\n");
    printf("  (1)   - Reset\n");
    printf("  (2)   - Set Resolution\n");
    printf("  (3)   - Read Temperature and Relative Humidity Once\n");
    printf("  (4)   - Read Temperature and Relative Humidity 20 Times\n");
    printf("  (5)   - Compute Dew Point\n");
    printf("  (6)   - Get Battery Status\n");
    printf("  (7)   - Get Heater Status\n");
    printf("  (8)   - Enable Heater\n");
    printf("  (9)   - Disable Heater\n");
    printf(" (ESC)  - Quit\n");
    printf("\n");

    return;
}
